# Prompts & Tool Schemas

*Document all prompts and tool schemas used by your agent.*

## System Prompts

### Main Agent System Prompt

```
(paste your system prompt here)
```

**Rationale:**

## Tool Schemas

### Tool: [Name]

**Purpose:**

**Schema:**
```json
{

}
```

## Other Prompts

(Add any other prompts used for extraction, generation, etc.)

## Design Notes

Any additional notes on your prompt engineering approach.
