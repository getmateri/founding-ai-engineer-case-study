#!/usr/bin/env python3
"""
Materi Case Study — Term Sheet Generation Agent

This is the entry point for your solution. Implement your agent here.

Expected outputs (in /out directory):
- extracted_data.json: All extracted information with sources and confidence
- conflicts.json: Any detected conflicts between sources
- user_decisions.json: Log of user decisions during the session
- term_sheet.md: Final generated term sheet with source annotations
- execution_log.json: Full execution trace for debugging

Run with: python src/main.py (or: make run)
"""

import os
import json
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Paths
ROOT_DIR = Path(__file__).parent.parent
DATA_DIR = ROOT_DIR / "data"
OUT_DIR = ROOT_DIR / "out"

# Ensure output directory exists
OUT_DIR.mkdir(exist_ok=True)


def main():
    """Main entry point for the term sheet generation agent."""
    
    # Verify API key is set
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Error: OPENAI_API_KEY environment variable not set")
        print("Set it with: export OPENAI_API_KEY='your-key-here'")
        return 1
    
    print("=" * 60)
    print("Materi — Term Sheet Generation Agent")
    print("=" * 60)
    print()
    print(f"Data directory: {DATA_DIR}")
    print(f"Output directory: {OUT_DIR}")
    print()
    
    # List available data files
    print("Available data files:")
    for f in DATA_DIR.rglob("*"):
        if f.is_file():
            rel_path = f.relative_to(DATA_DIR)
            print(f"  - {rel_path}")
    print()
    
    # =========================================================================
    # TODO: Implement your agent here
    # 
    # Your agent should:
    # 1. Read and understand context from all data sources
    # 2. Extract relevant information with confidence scores
    # 3. Detect conflicts between sources
    # 4. Engage the user at appropriate decision points
    # 5. Generate a term sheet with full provenance
    # 6. Handle user corrections gracefully
    #
    # See ASSIGNMENT.md for full requirements
    # =========================================================================
    
    print("TODO: Implement your agent")
    print()
    print("Your agent should produce the following outputs:")
    print(f"  - {OUT_DIR}/extracted_data.json")
    print(f"  - {OUT_DIR}/conflicts.json")
    print(f"  - {OUT_DIR}/user_decisions.json")
    print(f"  - {OUT_DIR}/term_sheet.md")
    print(f"  - {OUT_DIR}/execution_log.json")
    
    # Placeholder: Create empty output files
    # Remove this once you implement the actual agent
    placeholder_outputs = {
        "extracted_data.json": {"todo": "implement extraction"},
        "conflicts.json": {"todo": "implement conflict detection"},
        "user_decisions.json": {"todo": "implement user interaction"},
        "execution_log.json": {"todo": "implement logging"},
    }
    
    for filename, content in placeholder_outputs.items():
        with open(OUT_DIR / filename, "w") as f:
            json.dump(content, f, indent=2)
    
    with open(OUT_DIR / "term_sheet.md", "w") as f:
        f.write("# Term Sheet\n\nTODO: Generate term sheet\n")
    
    print()
    print("Placeholder outputs created. Replace with your implementation.")
    
    return 0


if __name__ == "__main__":
    exit(main())
