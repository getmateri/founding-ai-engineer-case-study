# Founding AI Engineer Case Study: Human-in-the-Loop Document Agent

## Overview

You are designing and building the core agent architecture for Materi, an AI-native document platform for knowledge workers. Your task is to create an intelligent document generation agent that demonstrates the human-in-the-loop philosophy central to our product.

**This is not a typical coding exercise.** We are evaluating your ability to make architectural decisions, handle ambiguity, design for uncertainty, and build systems that appropriately balance automation with human judgment.

**Deliverable:** Working agent + design documentation (details at end)

---

## The Problem

A venture capital firm uses multiple tools to manage their deal pipeline. When they decide to invest in a company, they need to generate a term sheet, a document summarizing the economic and control terms of the investment.

Currently, this process involves:

1. Pulling data from their deal model (Excel)
2. Referencing prior term sheets for similar deals
3. Checking their internal policies for standard terms
4. Manual synthesis and drafting

You are building an agent that assists with this workflow. The agent must demonstrate **appropriate uncertainty,** knowing when it's confident, when it needs clarification, and when a human must decide.

---

## Provided Materials

You will receive:

1. **`deal_model.xlsx`** — The financial model for this specific deal. Contains investment amounts, valuations, cap table projections, and proposed terms. Note: This is a real working model with multiple sheets, scenarios, and interdependencies. Not all cells are relevant.

2. **`termsheets/`** — A folder containing 3 anonymized term sheets from prior deals at the same firm. These represent the firm's historical preferences and language patterns.

3. **`firm_policy.md`** — Internal guidelines specifying the firm's standard positions on various terms (e.g., "We always require 1x non-participating liquidation preference for Series A deals under $5M").

**Important:** These sources may contain conflicting information. The deal model may specify terms that differ from firm policy. Prior term sheets may be inconsistent with each other. This is realistic and intentional.

---

## Requirements

### Core Functionality

Your agent must:

1. **Ingest and understand context** from all provided sources
2. **Identify what information is needed** for a term sheet (you determine the schema)
3. **Extract relevant data** with confidence scores and source attribution
4. **Detect conflicts and ambiguities** between sources
5. **Engage the user** at appropriate decision points
6. **Generate a term sheet** where every important value includes a reference showing exactly where it came from — which document, which cell or section, and how confident the agent is that it found the right value
7. **Handle corrections** when the user indicates something is wrong

### Critical Design Constraint: Appropriate Automation

The agent must implement a principled approach to deciding:

- What to do automatically (high confidence, low stakes)
- What to surface for confirmation (medium confidence or medium stakes)
- What to explicitly ask the user to decide (low confidence, high stakes, or policy-dependent)

**You must document your framework for making these decisions.**

### Uncertainty & Confidence

For each piece of extracted or inferred information, the agent must:

- Assign a confidence level
- Cite the source(s)
- Flag conflicts when multiple sources disagree
- Distinguish between "not found" and "found but uncertain"

### Human-in-the-Loop Checkpoints

Design the interaction flow yourself. Consider:

- What granularity of checkpoints? (Per-field? Per-section? Single confirmation?)
- What information does the user need to make good decisions quickly?
- How do you handle "go back and fix that" without restarting everything?
- What's the minimum viable interaction that still ensures accuracy?

### Error Recovery

Your agent must gracefully handle:

- User rejecting a proposed value ("No, the investment amount is $4M, not $4.5M")
- User adding information not in the sources ("Also include a 90-day no-shop, that was discussed verbally")
- User requesting a change to a choice that affects other parts of the document

---

## What We're Not Specifying

Unlike a typical take-home, we are intentionally leaving these decisions to you:

- **The term sheet schema:** You determine what fields are needed. Look at the prior term sheets and firm policy to understand the domain.
- **The clarification questions:** You determine what needs human input vs. what can be automated.
- **The agent architecture:** Design your own tool set, phases, and control flow.
- **The interaction UX:** CLI, web, or hybrid, your choice. Optimise for the reviewer being able to run and understand it.
- **The confidence thresholds:** What level of confidence warrants auto-fill vs. human review?

---

## Deliverables

### 1. Working Agent

- Single command to run: `make run` or equivalent
- Must work with provided `OPENAI_API_KEY` environment variable (we will provide the key separately)
- Should complete a full term sheet generation in under 3 minutes of wall time (excluding user input time)

### 2. `ARCHITECTURE.md`

Document your design decisions:

```markdown
# Architecture

## Problem Decomposition
How did you break down the problem? What are the key subproblems?

## Agent Design
- What tools/capabilities does your agent have?
- What is the control flow?
- How do you manage context across steps?

## Automation Framework
- How do you decide what to automate vs. ask the user?
- What are your confidence thresholds and why?
- How do you handle the trade-off between speed and accuracy?

## Conflict Resolution
- How do you detect conflicts between sources?
- How are these surfaced to users?
- What's your hierarchy when sources disagree?

## Error Recovery
- How does the agent handle user corrections?
- What state is preserved vs. recomputed?

## Limitations & Future Work
- What did you cut for time?
- What would you do differently with more time?
- What would need to change to support other document types?
```

### 3. `PROMPTS.md`

- All prompts used (system prompts, extraction prompts, etc.)
- Tool schemas
- Brief rationale for key prompt design decisions

### 4. `/out` Directory

After a successful run:

- `extracted_data.json` - All extracted information with sources and confidence
- `conflicts.json` - Any detected conflicts between sources
- `user_decisions.json` - Log of what the user decided
- `term_sheet.md` - Final output with source annotations
- `execution_log.json` - Full trace for debugging

### 5. `EVALUATION.md` (bonus)

If you have time: How would you evaluate this agent's quality at scale? What metrics matter? How would you catch regressions?

---

## Practical Notes

- **Model choice:** Use any OpenAI model. We'll provide the API key.
- **Libraries:** Use whatever you want. We like to see good judgment about dependencies.
- **Language:** Python preferred, but use what you're most effective in.
- **Questions:** If something is ambiguous, make a reasonable assumption and document it. That's part of the test.

---

## What Success Looks Like

A successful submission demonstrates that you can:

1. **Think from first principles:** about agent design, not just implement a spec
2. **Handle real-world messiness:** conflicting data, missing information, user corrections
3. **Design for humans:** the right checkpoints, the right information, the right level of control
4. **Build production-minded systems:** even in a prototype, we should see awareness of reliability, debuggability, and extensibility
5. **Communicate your thinking:** your documentation should make us confident you can lead technical discussions

We're not looking for a perfect system. We're looking for evidence that you can design and build the core AI capabilities of Materi.
